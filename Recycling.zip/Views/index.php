<?php include_once 'Views/template/header-principal.php'; ?>

<!-- banner section start -->
<div class="banner_section layout_padding">
    <div class="container">
        <div id="my_slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="row">
                        <div class="col-sm-12">
                            <h1 class="banner_taital" style="font-size: 34px;">No hay un planeta B,<br>así que reciclemos para preservar nuestro único hogar.</h1>
                            <div class="buynow_bt"><a href="#" class="btn btn-primary">Vender ahora</a></div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-12">
                            <h1 class="banner_taital" style="font-size: 34px;">Reciclar es el arte de dar nueva<br> vida a lo que muchos consideran basura.</h1>
                            <div class="buynow_bt"><a href="#" class="btn btn-primary">Vender ahora</a></div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-12">
                            <h1 class="banner_taital" style="font-size: 34px;">El reciclaje no es solo un acto<br> es un hábito que puede cambiar el mundo</h1>
                            <div class="buynow_bt"><a href="#" class="btn btn-primary">Vender ahora</a></div>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#my_slider" role="button" data-slide="prev">
                <i class="fa fa-angle-left"></i>
            </a>
            <a class="carousel-control-next" href="#my_slider" role="button" data-slide="next">
                <i class="fa fa-angle-right"></i>
            </a>
        </div>
    </div>
</div>
<!-- banner section end -->

<div class="fashion_section">
    <div class="container">
        <?php foreach ($data['categorias'] as $categoria) { ?>
            <div id="categoria_<?php echo $categoria['id']; ?>">
                <h1 class="fashion_taital text-uppercase"><?php echo $categoria['categoria']; ?></h1>
                <div class="row <?php echo (count($categoria['productos']) > 0) ? 'multiple-items' : ''; ?>">
                    <?php foreach ($categoria['productos'] as $producto) { ?>
                        <div class="<?php echo (count($categoria['productos']) > 2) ? 'col-lg-4' : 'col-lg-12'; ?>">
                            <div class="box_main">
                                <h4 class="shirt_text"><?php echo $producto['nombre']; ?></h4>
                                <p class="price_text">Precio <span style="color: #262626;">$ <?php echo $producto['precio']; ?></span></p>
                                <div class="text-center">
                                    <img data-lazy="<?php echo BASE_URL . $producto['imagen']; ?>" />
                                </div>
                                <div class="btn_main">
                                    <div class="buy_bt"><a href="#" class="btnAddcarrito" prod="<?php echo $producto['id']; ?>">Añadir</a></div>
                                    <div class="seemore_bt"><a href="#">Leer más</a></div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>

    
    <main>
        <section class="container about">
            <h2 class="subtitle">Aprendre con nosotros</h2>
            <p class="about__paragraph">Aprende sobre reciclaje es una excelente manera de contribuir al cuidado del medio ambiente. </p>

            <div class="about__main">
                <article class="about__icons">
                    <img src="../img/venta.png"  class="about__icon">
                    <h3 class="about__title">Como vender</h3>
                    <p class="about__paragrah">Aprende con nostros a vender materiar reciclable</p>
                </article>

                <article class="about__icons">
                    <img src="../img/aprender.png" class="about__icon">
                    <h3 class="about__title">Aprender a reciclar</h3>
                    <p class="about__paragrah">Reciclar es una practica cada vez mas importante en nustra sociedad moderna  </p>
                </article>

                <article class="about__icons">
                    <img src="../img/horario.png" class="about__icon">
                    <h3 class="about__title">Horario</h3>
                    <p class="about__paragrah">Conoce sobre nuestros horarios de antencion a los clientes</p>
                </article>
            </div>
        </section>

        

        <section class="knowledge">
            <div class="knowledge__container container">
                <div class="knowledege__texts">
                    <h2 class="subtitle">Conoce sobre nosotros</h2>
                    <p class="knowledge__paragraph">Recycling es un sitio web creado para ayudar a mitigar la contaminacion del medio ambiente y enseñar
                        a las personas como se hace y que con el materiar que reciclan pueden ganar dinero </p>
                    <a href="#" class="cta">Conocer mas sobre nostros</a>
                </div>

                <figure class="knowledge__picture">
                    <img src="../img/pngwing.com.png" class="knowledge__img">
                </figure>
            </div>
        </section>

        <section class="testimony">
            <div class="testimony__container container">
                <img src="../img/leftarrow.svg" class="testimony__arrow" id="before">

                <section class="testimony__body testimony__body--show" data-id="1">
                    <div class="testimony__texts">
                        <h2 class="subtitle">Carlos Mendez Losada <span class="testimony__course">Director de la CAM.</span></h2>
                        <p class="testimony__review">Reciclar no es solo una acción individual, sino un acto de responsabilidad colectiva que nos involucra a todos como habitantes 
                            de este planeta. Al separar y depositar correctamente los materiales reciclables, contribuimos a la creación de un ciclo virtuoso que beneficia al 
                            medio ambiente, a la economía y a la sociedad en su conjunto.!</p>
                    </div>

                    <figure class="testimony__picture">
                        <img src="../img/carlos.png" class="testimony__img">
                    </figure>
                </section>

                <section class="testimony__body" data-id="2">
                    <div class="testimony__texts">
                        <h2 class="subtitle">Maria Jose Cabrera <span class="testimony__course"> Biologa de la universisad de los andes.</span></h2>
                        <p class="testimony__review">Si bien el reciclaje es una herramienta poderosa para proteger el medio ambiente, no es la única solución. Es fundamental 
                            adoptar un enfoque integral que combine el reciclaje con otras medidas como la reducción del consumo, la reutilización de materiales y la compostaje.
                             Solo así podremos construir un futuro más sostenible para las generaciones venideras.</p>
                    </div>

                    <figure class="testimony__picture">
                        <img src="../img/sofia.png" class="testimony__img">
                    </figure>
                </section>

                <section class="testimony__body" data-id="3">
                    <div class="testimony__texts">
                        <h2 class="subtitle">Carlos Alberto Mendez <span class="testimony__course">Profesor de la universisad de la amazonia.</span></h2>
                        <p class="testimony__review">No perdamos la esperanza. La lucha por un planeta más limpio y sostenible es una tarea de todos. Si cada uno de nosotros aporta 
                                su granito de arena, podemos lograr grandes cambios. Reciclar es un paso importante en la dirección correcta, un paso que podemos dar hoy mismo 
                                para construir un futuro mejor.!</p>
                    </div>

                    <figure class="testimony__picture">
                        <img src="../img/jose.png" class="testimony__img">
                        
                    </figure>
                </section>



                <img src="../img/rightarrow.svg" class="testimony__arrow" id="next">
            </div>
        </section>

        <section class="questions container">
            <h2 class="subtitle">Preguntas frecuentes</h2>
            <p class="questions__paragraph">"El reciclaje es importante porque ayuda a conservar los recursos naturales, reduce la cantidad de desechos que van 
                a los vertederos y disminuye la contaminación del medio ambiente"</p>

            <section class="questions__container">
                <article class="questions__padding">
                    <div class="questions__answer">
                        <h3 class="questions__title">¿Cuál es la diferencia entre reciclar y reutilizar?
                            <span class="questions__arrow">
                                <img src="../img/arrow.svg" class="questions_img">
                            </span>
                        </h3>

                        <p class="questions__show">Reciclar implica convertir materiales usados en nuevos productos, mientras que reutilizar implica 
                            usar un producto o material varias veces para su mismo propósito o para un propósito diferente sin alteraciones significativas..</p>
                    </div>
                </article>

                <article class="questions__padding">
                    <div class="questions__answer">
                        <h3 class="questions__title"> ¿Qué pasa con los materiales reciclables una vez que los deposito en el contenedor de reciclaje?
                            <span class="questions__arrow">
                                <img src="../img/arrow.svg" class="questions_img">
                            </span>
                        </h3>

                        <p class="questions__show">Una vez que los materiales reciclables se depositan en el contenedor de reciclaje, son recolectados 
                            y transportados a instalaciones de reciclaje donde son clasificados, procesados y convertidos en nuevos productos o materiales.</p>
                    </div>
                </article>

                <article class="questions__padding">
                    <div class="questions__answer">
                        <h3 class="questions__title">¿Qué impacto tiene el reciclaje en la economía y la creación de empleo?
                            <span class="questions__arrow">
                                <img src="../img/arrow.svg" class="questions_img">
                            </span>
                        </h3>

                        <p class="questions__show">El reciclaje puede generar beneficios económicos al promover la industria del reciclaje y la reutilización 
                            de materiales. Además, puede crear empleos en áreas como la recolección, clasificación, procesamiento y fabricación de productos reciclados.
                             Esto no solo impulsa la economía local, sino que también fomenta la innovación en tecnologías y prácticas sostenibles.</p>
                    </div>
                </article>
            </section>

            <section class="questions__offer">
                <h2 class="subtitle">¿Estas listo para empezar a reciclar?</h2>
                <p class="questions__copy">En nombre de Recycling, estamos comprometidos con la preservación del medio ambiente y queremos invitarte a
                     formar parte de esta importante misión. ¿Estás listo para reciclar con nosotros?</p>
                <a href="#" class="cta">Comenzar ahora</a>
            </section>
        </section>
    </main>


</section>
                    </div>



<?php include_once 'Views/template/footer-principal.php'; ?>

<script>
  $('.multiple-items').slick({
    lazyLoad: 'ondemand',
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    responsive: [{
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  });
</script>

</body>

</html>