<?php
const BASE_URL = "http://localhost/recycling/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "tienda-online";
const CHARSET = "charset=utf8";
const TITLE = "TIENDA ONLINE";
const MONEDA = "USD";
const CLIENT_ID = "";

const USER_SMTP = "recycling604@gmail.com";
const PASS_SMTP = "llvc psii vpps vvgv";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";
?>
